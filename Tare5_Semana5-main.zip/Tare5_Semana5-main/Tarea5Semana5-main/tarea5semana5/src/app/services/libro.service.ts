import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LibroService {
  RUTA_API="https://localhost:7273/Api/Libro"
  constructor(private http:HttpClient) {}

  //todos 
  todos():Observable<any[]>{
    return this.http.get<any[]>(this.RUTA_API)
  }  

  uno(idlibro:number):Observable<any>{
    console.log(this.RUTA_API + "/"+idlibro)
    return this.http.get(this.RUTA_API + "/"+idlibro)
  }

  nuevoLibro(libro:any): Observable<any>{
    return this.http.post<any>(this.RUTA_API, libro)
  }
  editar(libro:any): Observable<any>{
    return this.http.put<any>(this.RUTA_API + "/"+libro.id, libro)
  }

  eliminar(idlibro:number):Observable<any>{
   
    return this.http.delete(this.RUTA_API + "/"+idlibro)
  }
}
