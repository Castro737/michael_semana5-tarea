import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Menu } from './menu/menu';
import { NuevoLibro } from './libro/nuevo-libro/nuevo-libro';
@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Menu, NuevoLibro],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('tarea5semana5');
}
