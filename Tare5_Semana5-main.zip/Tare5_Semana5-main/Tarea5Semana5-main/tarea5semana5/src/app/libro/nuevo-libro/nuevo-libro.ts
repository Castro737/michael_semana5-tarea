import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Route, Router, RouterLink } from '@angular/router';
import { LibroService } from '../../services/libro.service';

@Component({
  selector: 'app-nuevo-libro',
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: './nuevo-libro.html',
  styleUrl: './nuevo-libro.css',
})
export class NuevoLibro {

  titulo = false;
  idlibro = 0;

  frmLibro: FormGroup = new FormGroup({
    id: new FormControl<number | null>(null),
    isbn: new FormControl('', [Validators.required, Validators.maxLength(100)]),
    nombre: new FormControl('', [Validators.required, Validators.maxLength(100)]),
    autor: new FormControl('', [Validators.required, Validators.maxLength(100)]),
    editorial: new FormControl('', [Validators.required, Validators.maxLength(100)]),
    fechaPublicacion: new FormControl('', [Validators.required]),
    numeroPaginas: new FormControl('', [Validators.required, Validators.min(1)]),
    descripcion: new FormControl('', [Validators.required, Validators.maxLength(500)]),
  });
  constructor(private _libroServicio:LibroService, private rutas:Router, 
    private parametros:ActivatedRoute){

      this.parametros.paramMap.subscribe(
        valores =>{
          const id = Number(valores.get("id"));
          if (id>0){
            this.titulo = true
            this._libroServicio.uno(id).subscribe(
              libro =>{
                this.idlibro = libro.id
                this.frmLibro.patchValue({
                    id: libro.id,
                    isbn: libro.isbn,
                    nombre: libro.nombre,
                    autor: libro.autor,
                    editorial: libro.editorial,
                    fechaPublicacion: libro.fechaPublicacion,
                    numeroPaginas: libro.numeroPaginas,
                    descripcion: libro.descripcion
                })
              }
            );
          }
        }
      )

  }


guardar() {
    const datosLibro = this.frmLibro.getRawValue();
    const libroModel  = {
      id: datosLibro.id ?? 0,
      isbn: datosLibro.isbn.trim(),
      nombre: datosLibro.nombre.trim(),
      autor: datosLibro.autor.trim(),
      editorial: datosLibro.editorial.trim(),
      fechaPublicacion: datosLibro.fechaPublicacion,
      numeroPaginas: datosLibro.numeroPaginas,
      descripcion: datosLibro.descripcion.trim(),
    };

    console.log(libroModel)
    if(this.titulo == true){

      

      this._libroServicio.editar(libroModel).subscribe((response) => {
        console.log(response)
     if(response == null){
          alert("Se guardo con exito")
          this.rutas.navigate(["/libro"])
     }
    });
    }else{
      this._libroServicio.nuevoLibro(libroModel).subscribe((response) => {
          if(response.id > 0){
                alert("Se guardo con exito")
                this.rutas.navigate(["/libro"])
          }
          });
    }
  }
}