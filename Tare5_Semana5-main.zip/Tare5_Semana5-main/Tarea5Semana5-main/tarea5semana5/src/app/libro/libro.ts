import { Component, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import {LibroService} from '../services/libro.service'
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-libro',
  imports: [RouterLink, FormsModule, CommonModule],  //, 
  templateUrl: './libro.html',
  styleUrl: './libro.css'

})
export class Libro implements OnInit  {

  listalibros = signal<any[]>([])
  constructor(private readonly libroService:LibroService) {}

  ngOnInit(): void {
   this.cargarlista();
  }

  cargarlista(){
     this.libroService.todos().subscribe(lista =>
      {
        console.table(lista)
        this.listalibros.set(Array.isArray(lista) ? lista : [])
      }
    )
  }
  uno(idlibro:number){

    this.libroService.uno(idlibro).subscribe(
      libro =>{
        //enviar al componente para edirtar
      }
    )

  }

eliminar(id:number){
  this.libroService.eliminar(id).subscribe(
    response =>{
      if(response == null){
        alert("Se eliminó el libro con id: "+id)
this.cargarlista();
      }
    }

  )

}
  
}