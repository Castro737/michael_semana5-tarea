import { Routes } from '@angular/router';
import { Libro } from './libro/libro';
import { NuevoLibro } from './libro/nuevo-libro/nuevo-libro';

export const routes: Routes = [
  {
    path: '',
    component: Libro,
    pathMatch: 'full'
  },
  {
    path: 'libro',
    component: Libro
  },
  {
    path: 'nuevoLibro',
    component: NuevoLibro
  },
  {
    path: 'editarLibro/:id',
    component: NuevoLibro
  },
  {
    path: '**',
    redirectTo: 'libro'
  }
];
