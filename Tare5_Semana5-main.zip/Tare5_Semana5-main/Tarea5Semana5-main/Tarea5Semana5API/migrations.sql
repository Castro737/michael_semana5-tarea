﻿CREATE TABLE IF NOT EXISTS `__EFMigrationsHistory` (
    `MigrationId` varchar(150) NOT NULL,
    `ProductVersion` varchar(32) NOT NULL,
    PRIMARY KEY (`MigrationId`)
);

START TRANSACTION;
CREATE TABLE `Libros` (
    `id` int NOT NULL AUTO_INCREMENT,
    `isbn` longtext NOT NULL,
    `nombre` longtext NOT NULL,
    `autor` longtext NOT NULL,
    `descripcion` longtext NOT NULL,
    `fechaPublicacion` datetime(6) NOT NULL,
    `numeroPaginas` int NOT NULL,
    `editorial` longtext NOT NULL,
    PRIMARY KEY (`id`)
);

INSERT INTO `__EFMigrationsHistory` (`MigrationId`, `ProductVersion`)
VALUES ('20260215140813_NuevaMigracion', '10.0.3');

COMMIT;

