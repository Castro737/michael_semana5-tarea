﻿namespace Tarea5Semana5API.Models
{
    //BACKEND DE TAREA5 SEMANA5 ANGULAR
    public class LibroModel
    {
        public int id { get; set; }
        public string isbn { get; set;  }
        public string nombre { get; set; }
        public string autor { get; set; }
        public string descripcion { get; set; }
        public DateTime fechaPublicacion { get; set; }
        public int numeroPaginas { get; set; }
        public string editorial { get; set; }
    }
}
