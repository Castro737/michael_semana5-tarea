﻿using Microsoft.EntityFrameworkCore;

namespace Tarea5Semana5API.Models
{
    using Microsoft.EntityFrameworkCore;
    using System; 
    public class Tarea5Semana5AppContext:DbContext
    {
        public Tarea5Semana5AppContext(DbContextOptions<Tarea5Semana5AppContext> options) : base(options) { }
        public DbSet<LibroModel> Libros {  get; set; }
    }
}
